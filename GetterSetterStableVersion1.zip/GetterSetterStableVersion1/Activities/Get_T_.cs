using Newtonsoft.Json;
using System;
using System.Activities;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace GetterSetterActivity.Activities
{
	public sealed class Get<T> : CodeActivity
	{
		[Category("Output")]
		public OutArgument<string> ErrorDescription
		{
			get;
			set;
		}

		[Category("Input")]
		[RequiredArgument]
		public InArgument<string> Name
		{
			get;
			set;
		}

		[Category("Output")]
		public OutArgument<T> Value
		{
			get;
			set;
		}

		public Get()
		{
		}

		protected override void Execute(CodeActivityContext context)
		{
			try
			{
				this.Value.Set(context, JsonConvert.DeserializeObject<T>(Application.Current.Resources[this.Name.Get(context)].ToString()));
				this.ErrorDescription.Set(context, "");
			}
			catch (Exception exception)
			{
				this.ErrorDescription.Set(context, exception.ToString());
			}
		}
	}
}