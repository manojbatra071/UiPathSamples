using Newtonsoft.Json;
using System;
using System.Activities;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace GetterSetterActivity.Activities
{
	public class Set<T> : CodeActivity
	{
		[Category("Output")]
		public OutArgument<string> ErrorDescription
		{
			get;
			set;
		}

		[Category("Input")]
		[RequiredArgument]
		public InArgument<string> Name
		{
			get;
			set;
		}

		[Category("Input")]
		[RequiredArgument]
		public InArgument<T> Value
		{
			get;
			set;
		}

		public Set()
		{
		}

		protected override void Execute(CodeActivityContext context)
		{
			try
			{
				Application.Current.Resources[this.Name.Get(context)] = JsonConvert.SerializeObject(this.Value.Get(context));
				this.ErrorDescription.Set(context, "");
			}
			catch (Exception exception)
			{
				this.ErrorDescription.Set(context, exception);
			}
		}
	}
}