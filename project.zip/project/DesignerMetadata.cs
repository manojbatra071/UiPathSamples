using GetterSetterActivity.Activities;
using GetterSetterActivity.Designer;
using System;
using System.Activities.Presentation;
using System.Activities.Presentation.Metadata;
using System.ComponentModel;

namespace GetterSetterActivity
{
	public class DesignerMetadata : IRegisterMetadata
	{
		public DesignerMetadata()
		{
		}

		public void Register()
		{
			AttributeTableBuilder attributeTableBuilder = new AttributeTableBuilder();
			attributeTableBuilder.AddCustomAttributes(typeof(Set<>), new Attribute[] { new DesignerAttribute(typeof(SetterDesigner)) });
			attributeTableBuilder.AddCustomAttributes(typeof(Get<>), new Attribute[] { new DesignerAttribute(typeof(GetterDesigner)) });
			Type type = Type.GetType("System.Activities.Presentation.FeatureAttribute, System.Activities.Presentation, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
			Type type1 = Type.GetType("System.Activities.Presentation.UpdatableGenericArgumentsFeature, System.Activities.Presentation, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35");
			Attribute attribute = Activator.CreateInstance(type, new object[] { type1 }) as Attribute;
			attributeTableBuilder.AddCustomAttributes(typeof(Set<>), new Attribute[] { new DefaultTypeArgumentAttribute(typeof(string)) });
			attributeTableBuilder.AddCustomAttributes(typeof(Set<>), new Attribute[] { attribute });
			attributeTableBuilder.AddCustomAttributes(typeof(Get<>), new Attribute[] { new DefaultTypeArgumentAttribute(typeof(string)) });
			attributeTableBuilder.AddCustomAttributes(typeof(Get<>), new Attribute[] { attribute });
			MetadataStore.AddAttributeTable(attributeTableBuilder.CreateTable());
		}
	}
}