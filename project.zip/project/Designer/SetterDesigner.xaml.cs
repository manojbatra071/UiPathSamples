using System;
using System.Activities.Presentation;
using System.Activities.Presentation.View;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace GetterSetterActivity.Designer
{
	public partial class SetterDesigner : ActivityDesigner
	{
		public SetterDesigner()
		{
			this.InitializeComponent();
		}
	}
}