import cv2
import numpy as np
import time
import random
import math

# -------- CONFIG ----------
IMAGE_PATH = "Manoj.jpg"
DURATION_SECONDS = 15.0       # total reveal time
UNRECOGNIZABLE_UNTIL = 9.0  # remain hidden until 12s, reveal from 12->15
FPS = 20

# Obfuscation (early) settings
MAX_BLUR = 161               # large odd kernel for hidden phase
MAX_PIXEL_SCALE = 40         # pixelation for hidden phase
NOISE_START_STD = 80.0
TILE_SCRAMBLE_SIZE = 60
PATCHES_FINAL = 120
PATCH_MAX_RADIUS = 140

WINDOW_NAME = "Guess Who? (press q to quit)"

# ---------- helpers ----------
def odd(x):
    x = int(x)
    return x if x % 2 == 1 else x + 1

def add_gaussian_noise(img, std):
    if std <= 0:
        return img
    noise = np.random.normal(0, std, img.shape).astype(np.float32)
    noisy = img.astype(np.float32) + noise
    return np.clip(noisy, 0, 255).astype(np.uint8)

def pixelate(img, scale):
    if scale <= 1:
        return img
    h, w = img.shape[:2]
    small_w = max(1, w // scale)
    small_h = max(1, h // scale)
    small = cv2.resize(img, (small_w, small_h), interpolation=cv2.INTER_NEAREST)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)

def scramble_tiles(img, tile_size):
    h, w = img.shape[:2]
    out = img.copy()
    # grid
    tiles_x = max(1, w // tile_size)
    tiles_y = max(1, h // tile_size)
    coords = [(i, j) for j in range(tiles_y) for i in range(tiles_x)]
    shuffled = coords.copy()
    random.shuffle(shuffled)
    for (i, j), (si, sj) in zip(coords, shuffled):
        x0, y0 = i * tile_size, j * tile_size
        x1, y1 = min(w, x0 + tile_size), min(h, y0 + tile_size)
        sx0, sy0 = si * tile_size, sj * tile_size
        sx1, sy1 = min(w, sx0 + tile_size), min(h, sy0 + tile_size)
        tile = img[sy0:sy1, sx0:sx1]
        if tile.size == 0:
            continue
        out[y0:y1, x0:x1] = cv2.resize(tile, (x1 - x0, y1 - y0), interpolation=cv2.INTER_LINEAR)
    return out

def strong_edge_overlay(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    edges_col = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
    return cv2.addWeighted(img, 0.6, cv2.bitwise_not(edges_col), 0.4, 0)

# ---------- load image ----------
img = cv2.imread(IMAGE_PATH)
if img is None:
    print(f"Error: cannot load '{IMAGE_PATH}'")
    raise SystemExit(1)

# optional resize for performance
MAX_WIDTH = 900
h0, w0 = img.shape[:2]
if w0 > MAX_WIDTH:
    scale = MAX_WIDTH / float(w0)
    img = cv2.resize(img, (int(w0 * scale), int(h0 * scale)), interpolation=cv2.INTER_AREA)
h, w = img.shape[:2]

# pre-generate patches
random.seed(42)
patches = []
for i in range(PATCHES_FINAL):
    cx = random.randint(0, w-1)
    cy = random.randint(0, h-1)
    r = random.randint(10, PATCH_MAX_RADIUS)
    patches.append((cx, cy, r))

# ---- Prepare discrete blur kernels for reveal (large -> 1) ----
# We'll create a list of *odd* kernel sizes descending to 1, spaced roughly like your example.
# Example pattern: range(161, 1, -8) (we'll adapt step based on reveal frames)
reveal_seconds = DURATION_SECONDS - UNRECOGNIZABLE_UNTIL
reveal_frames = max(1, int(reveal_seconds * FPS))

# create a descending odd-kernel list from MAX_BLUR down to 1 with length = reveal_frames
def make_odd_kernel_list(max_k, n_steps):
    max_k = odd(max_k)
    if n_steps <= 1:
        return [1]
    # create n_steps values between max_k and 1 (inclusive), then round to nearest odd int
    vals = np.linspace(max_k, 1, n_steps)
    ks = [int(round(v)) for v in vals]
    ks = [odd(max(1, k)) for k in ks]
    # ensure strictly descending by adjusting duplicates if needed
    for i in range(1, len(ks)):
        if ks[i] >= ks[i-1]:
            ks[i] = max(1, ks[i-1] - 2)
            ks[i] = odd(ks[i])
    # final safety: replace any zero or negative with 1
    ks = [k if k >= 1 else 1 for k in ks]
    return ks

reveal_kernels = make_odd_kernel_list(MAX_BLUR, reveal_frames)

# Also prepare pixel scales for reveal frames (from MAX_PIXEL_SCALE -> 1)
pixel_scales = list(np.linspace(MAX_PIXEL_SCALE, 1, reveal_frames).astype(int))
pixel_scales = [max(1, int(x)) for x in pixel_scales]

# Frame loop
total_frames = int(DURATION_SECONDS * FPS)
start_time = time.time()
cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_AUTOSIZE)

for frame in range(total_frames + 1):
    elapsed = time.time() - start_time
    seconds_left = max(0, DURATION_SECONDS - elapsed)

    if elapsed < UNRECOGNIZABLE_UNTIL:
        # EARLY HIDDEN PHASE (0 .. 12s)
        early_phase = True
        # extreme obfuscation
        blurred = cv2.GaussianBlur(img, (odd(MAX_BLUR), odd(MAX_BLUR)), 0)
        pixel_layer = pixelate(img, MAX_PIXEL_SCALE)
        scrambled = scramble_tiles(pixel_layer, TILE_SCRAMBLE_SIZE)
        combined_bg = strong_edge_overlay(scrambled)
        combined_bg = add_gaussian_noise(combined_bg, NOISE_START_STD)
        combined = combined_bg
        status2 = "Hidden"
    else:
        # REVEAL PHASE (12 .. 15s)
        early_phase = False
        # map elapsed within reveal window to an index in reveal_kernels / pixel_scales
        rel = min(1.0, (elapsed - UNRECOGNIZABLE_UNTIL) / max(1e-6, reveal_seconds))
        idx = min(len(reveal_kernels)-1, int(rel * (len(reveal_kernels)-1)))
        k = reveal_kernels[idx]
        pscale = pixel_scales[idx]

        # Apply discrete blur like your snippet: reduce blur according to k, but also blend with pixelation and slight noise for smoothness
        blurred = cv2.GaussianBlur(img, (k, k), 0) if k > 1 else img.copy()
        pixel_layer = pixelate(img, pscale)
        # blend blurred and pixel layer slightly depending on rel (early reveal -> more pixel)
        pixel_weight = max(0.0, 1.0 - rel*1.5)
        mixed = cv2.addWeighted(blurred, 1.0 - pixel_weight, pixel_layer, pixel_weight, 0)
        # small amount of noise that decays as reveal progresses
        noise_std = NOISE_START_STD * (1.0 - rel)
        mixed = add_gaussian_noise(mixed, noise_std)
        # progressive mask patches (so reveal isn't purely global — keeps a playful feel)
        patches_to_show = int(PATCHES_FINAL * rel)
        mask = np.zeros((h, w), dtype=np.float32)
        for i in range(patches_to_show):
            cx, cy, r = patches[i]
            grow = int(r * (0.2 + 0.8 * rel))
            y, x = np.ogrid[:h, :w]
            circle = (x - cx)**2 + (y - cy)**2 <= grow**2
            mask[circle] = 1.0
        mask = cv2.GaussianBlur((mask * 255).astype(np.uint8), (21, 21), 0).astype(np.float32) / 255.0
        mask_3 = np.repeat(mask[:, :, None], 3, axis=2)

        combined = (img.astype(np.float32) * mask_3) + (mixed.astype(np.float32) * (1.0 - mask_3))
        combined = np.clip(combined, 0, 255).astype(np.uint8)
        status2 = f"Revealing ({int(rel*100)}%) - blur k={k}"

    # small jitter in hidden phase to avoid static cues
    if early_phase:
        if frame % 2 == 0:
            dx = random.randint(-6, 6)
            dy = random.randint(-6, 6)
            M = np.float32([[1, 0, dx], [0, 1, dy]])
            combined = cv2.warpAffine(combined, M, (w, h), borderMode=cv2.BORDER_REFLECT)

    # overlay countdown and status
    status = f"Time left: {int(math.ceil(seconds_left))}s"
    cv2.putText(combined, status, (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255,255,255), 2, cv2.LINE_AA)
    cv2.putText(combined, status2, (30, h - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (220,220,220), 2, cv2.LINE_AA)

    cv2.imshow(WINDOW_NAME, combined)
    if cv2.waitKey(int(1000 / FPS)) & 0xFF == ord('q'):
        break

    if elapsed >= DURATION_SECONDS:
        cv2.waitKey(1000)
        break

cv2.destroyAllWindows()
