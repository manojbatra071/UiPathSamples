import joblib, json, pandas as pd

MODEL = None
SCALER = None

def init():
    global MODEL, SCALER
    MODEL = joblib.load("model.pkl")
    SCALER = joblib.load("scaler.pkl")

def run(inputs):
    # inputs could be JSON string or dict
    if isinstance(inputs, str):
        data = json.loads(inputs)
    else:
        data = inputs
    if isinstance(data, dict) and "records" in data:
        records = data["records"]
    else:
        records = data
    df = pd.DataFrame(records)
    X = df[["transaction_amount","policy_code","other_feature"]]
    X_scaled = SCALER.transform(X)
    preds = MODEL.predict(X_scaled)
    df["prediction"] = ["normal" if p==1 else "anomaly" for p in preds]
    return {"predictions": df.to_dict(orient="records")}