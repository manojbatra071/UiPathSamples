# IsolationForest Anomaly Detector
This repo contains a scikit-learn IsolationForest model and scaler trained on a synthetic transactions dataset.
Files included:
- model.pkl
- scaler.pkl
- app.py (Gradio demo for Spaces)
- inference.py (HF Inference Endpoint hooks)
- requirements.txt

Train data used: synthetic_transactions.csv (saved alongside this repo)
Generated at: 2025-10-24T16:11:52.572718Z