import gradio as gr
import json
import pandas as pd
import joblib

MODEL = joblib.load("model.pkl")
SCALER = joblib.load("scaler.pkl")

def predict_json(input_json):
    try:
        records = json.loads(input_json)
    except Exception:
        return {"error": "Invalid JSON. Expecting a JSON array or object with key 'records'."}
    if isinstance(records, dict) and "records" in records:
        records = records["records"]
    df = pd.DataFrame(records)
    X = df[["transaction_amount","policy_code","other_feature"]]
    X_scaled = SCALER.transform(X)
    preds = MODEL.predict(X_scaled)
    df["prediction"] = ["normal" if p==1 else "anomaly" for p in preds]
    return df.to_dict(orient="records")

demo = gr.Interface(
    fn=predict_json,
    inputs=gr.Textbox(lines=6, placeholder='Enter JSON array or {"records": [...] }'),
    outputs=gr.JSON(),
    title="IsolationForest Anomaly Detector",
    description="Send JSON array of records. Example: [{\"transaction_amount\":120.5,\"policy_code\":1,\"other_feature\":0.85}]"
)

if __name__ == '__main__':
    demo.launch()